// web location of the content host's dispatch files (dispatch.client.loader.js, DispatchHost.html, etc.)
DispatchRoot = 'https://elearning-engine.dev.zosilearning.com/dispatch/';

// version of dispatch
DispatchVersion = '1';

// web location of the content host's launch process which ultimately leads to the content host Engine launch URL
ContentURL = 'https://elearning-engine.dev.zosilearning.com/dispatch/DispatchRequest.jsp?methodName=Launch&tenant=default&dispatchid=985da4cc-57f3-41dc-be20-26e7546bc680&launchsecret=1RDHEOJKDE_A0QlJreCz1VT9hYJK&learnerid=LEARNER_ID&fname=LEARNER_FNAME&lname=LEARNER_LNAME&pipeurl=PIPE_URL&redirecturl=REDIRECT_URL_REGISTRATION_ARGUMENT';

// optional web location that provides pre-launch configuration object
PreLaunchConfigurationURL = 'https://elearning-engine.dev.zosilearning.com/dispatch/DispatchRequest.jsp?methodName=PreLaunchConfiguration&tenant=default&dispatchid=985da4cc-57f3-41dc-be20-26e7546bc680&launchsecret=1RDHEOJKDE_A0QlJreCz1VT9hYJK';
